"""Agentic RAG utilities."""
